print("Status: 301")
print("Location: /static/demos/index.html")
print("")
